#!/usr/bin/bash
echo ========== alter_database.sh
alter_source=$(dirname $0)

#alter_database() {
#
#}

create_table() {
	. "$alter_source/../metadata/metadata_creation.sh"
}

drop_table() {

}
